class Important{

    String apiUrl;
    String primary;

    
    Important({
      this.apiUrl ='http://34.79.92.74/redoc',
      this.primary= 'test3',
    });
    
     
}