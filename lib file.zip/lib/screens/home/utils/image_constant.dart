class ImageConstant {


  
  static String imgVector = 'assets/images/img_vector.svg';

  static String imgVector2 = 'assets/images/img_vector_2.svg';

  static String imgVector1 = 'assets/images/img_vector_1.svg';

  static String imgRectangle5 = 'assets/images/img_rectangle5.png';

  static String imgRectangle4 = 'assets/images/img_rectangle4.png';

  static String imgVecteezycasset = 'assets/images/img_vecteezycasset.png';

  static String imgVector3 = 'assets/images/img_vector_3.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
