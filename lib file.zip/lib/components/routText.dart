 
import 'package:flutter/material.dart';
import 'package:kin_music/screens/home/home.dart';
import 'package:kin_music/screens/home/login.dart';

import 'package:kin_music/screens/home/register.dart';


final Map<String, WidgetBuilder> routesx = {
  '/' : (context) => login(),
  '/reg' : (context) =>  register(),
  '/home': (context) => homex()
};  