import 'package:flutter/material.dart';
import 'package:kin_music/components/routText.dart';
import 'package:kin_music/screens/google.dart';
import 'package:kin_music/screens/home/login.dart';
import 'package:kin_music/screens/home/register.dart';
import '../../components/mainNav.dart';
import '../../screens/home/home.dart';
import 'package:provider/provider.dart';

import 'provider/userProvider.dart';
  
 void main(){
   runApp(ChangeNotifierProvider(create: (_)=> userProvider(), child: start())  );
 }

 class start extends StatefulWidget{
   @override 
   _main_state createState() => _main_state();
 }

 class _main_state extends State<start>{

   Widget build(BuildContext context){
      
     return  MaterialApp(
       debugShowCheckedModeBanner: false,
        
      //  initialRoute: '/',
      //  routes: routesx,
      home: login()
     );
        
   }
 }