import 'package:flutter/material.dart';
import '../network/api_service.dart';

class userProvider extends ChangeNotifier{
  var isLoading = false;

  Future getUsers(url) async{
      isLoading = true;
      notifyListeners();
      var get = await getUserApi(url);
      isLoading =false;
      notifyListeners();
      return get;
  }


  Future login(url, data) async {
    isLoading = true;
    notifyListeners();
    var ask = await loginApi(url, data);
    isLoading = false;
    return ask;
  }



  Future<dynamic> register(url, username, email, password) async{
    isLoading = true;
    notifyListeners();
    var data = {
      'username': '$username',
      'email': '$email',
      'password' : '$password'
    };
    var ask = await registerApi(url, data);
    isLoading = false;
    notifyListeners();
    return ask;
  }

  Future getUserData(url) async {
      isLoading = true;
      notifyListeners();
      var ask = await getUserDataApi(url);
      notifyListeners();
      return ask;
}
}




 