import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';


Future<dynamic>  getUserApi(apiUrl) async {
  Response res = await get(apiUrl );
  final data =  jsonEncode(res.body);
  if(res.statusCode == 200){
return data;
  }else{
    return 'error';
  }
   
}


Future loginApi(apiUrl, data) async {
    Response res = await post(apiUrl,
    body: data
     );
    var out = jsonEncode(res.body);
     return out;
    
}


Future registerApi(apiUrl, data) async {
  Response res = await post(
    apiUrl,
    body: data
    );
    var out = jsonEncode(res.body) ;
    return out;
}



Future getUserDataApi(apiUrl) async{
  Response res = await get(
    apiUrl,

  );
  var out = jsonEncode(res.body);
  return out;
}